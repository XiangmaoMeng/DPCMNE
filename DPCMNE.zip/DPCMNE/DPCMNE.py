import numpy as np
from tqdm import tqdm
import pandas as pd
import time
import math
from collections import defaultdict
import os


def load_data(PPIfile):
    relations = defaultdict(list)
    protein_id, id_protein = {}, {}
    
    with open(PPIfile, 'r') as f:
        content = f.readlines()
        for line in content:
            line = line.strip('\n').split('\t')
            protein_source = line[0]
            protein_destination = line[1]
            
            if protein_source not in protein_id.keys():
                newid = len(protein_id)
                protein_id[protein_source] = newid
                id_protein[newid] = protein_source
            if protein_destination not in protein_id.keys():
                newid = len(protein_id)
                protein_id[protein_destination] = newid
                id_protein[newid] = protein_destination
            
            protein_source_id = protein_id[protein_source]
            protein_destination_id = protein_id[protein_destination]
            if protein_source_id == protein_destination_id:
                continue
            if protein_destination_id not in relations[protein_source_id]:
                relations[protein_source_id].append(protein_destination_id)
                relations[protein_destination_id].append(protein_source_id)
    return relations, protein_id, id_protein

def cal_cosine(x, y):
    assert len(x) == len(y), "emd error"
    res = np.array( [[x[i]*y[i], x[i]*x[i], y[i]*y[i]] for i in range(len(x))] )
    cos = sum(res[:, 0]) / (np.sqrt(sum(res[:, 1])) * np.sqrt(sum(res[:, 2])))
    return cos


def construct_net_embedding(id_protein, protein_id, relations, w, emd_file):
    emd = {}
    with open(emd_file, 'r') as f:
        content = f.readlines()
        for line in content:
            line = line.strip('\n').strip().split()
            emd_temp = []
            for i, val in enumerate(line):
                if i == 0:
                    protein_name = val
                else:
                    emd_temp.append(float(val))
            emd[protein_id[protein_name]] = emd_temp
    
    protein_num = len(id_protein)
    for u in range(protein_num):
        N_u = relations[u]
        for v in N_u:
            weight = cal_cosine(emd[u], emd[v])
            w[u][v] = weight
    
    return w, relations

def cal_density(proteins, w):
    score = 0.0
    for u in proteins:
        for v in proteins:
            if u==v:
                continue
            else:
                score += w[u][v]
    protein_num = len(proteins)
    score = score / (protein_num * (protein_num-1))
    return score

def select_cores(Cores_score, w):
    Cores = []
    while True:
        new_cores_score = []
        
        cur_core = set(Cores_score[0][0])
        Cores.append(cur_core)
        for i, tup in enumerate(Cores_score):
            if i==0:
                continue
            else:
                core = set(tup[0])
                if len(core&cur_core)==0:
                    new_cores_score.append(core)
                elif len(core - cur_core)>=3:
                    new_cores_score.append(core - cur_core)
        
#         print(new_cores_score[:4])
        Cores_score = []
        for core in new_cores_score:
#             print(core)
            density_score = cal_density(core, w)
            temp = (core, density_score)
            Cores_score.append(temp)
        Cores_score.sort(key=lambda tup: tup[1], reverse=True)
        
        if len(Cores_score)==1:
            cur_core = set(Cores_score[0][0])
            Cores.append(cur_core)
            break
    return Cores

def extension(Cores, id_protein, w, extension_thres):
    complexes = []
    protein_num = len(id_protein)
    for core in Cores:
        temp_complex = set()
        for i in range(protein_num):
            if i in core:
                continue
            else:
                connectivity = 0.0
                for j in core:
                    connectivity += w[i][j]
                connectivity = connectivity/len(core)
                
                if connectivity>=extension_thres:
                    temp_complex.add(i)
        temp_complex = temp_complex|core
        complexes.append(temp_complex)
    return complexes

def save_result(complexes, id_protein, result_file):
    with open(result_file, 'w') as f:
        rowid = 0
        for u in complexes:
            cps = list(u)
            if len(cps) >= 3:
                rowid += 1
                content = str(rowid)
                for pid in cps:
                    content = content + ' ' + id_protein[pid]
                content +='\n'
                f.writelines(content)
    print('Save Results to file: ', result_file)

def cal_os(pcs, kcs):
    pc_number = len(pcs)
    kc_number = len(kcs)
    os_matrix = np.zeros((pc_number, kc_number))
    
    for i, pc in enumerate(pcs):
        pc_set = set(pc)
        for j, kc in enumerate(kcs):
            kc_set = set(kc)
            inter = pc_set & kc_set
            os_number = float(len(inter)*len(inter)) / (len(pc_set)*len(kc_set))
            os_matrix[i][j] = os_number
#             print(os_number)
    
    return os_matrix

def cal_Npc(pcs, kcs, os_matrix, lamda_w = 0.2):
    N_pc = 0
    for i, pc in enumerate(pcs):
        for j, kc in enumerate(kcs):
            if os_matrix[i][j] >= lamda_w:
                N_pc += 1
                break
    return N_pc

def cal_Nkc(pcs, kcs, os_matrix, lamda_w = 0.2):
    N_kc = 0
    for j, kc in enumerate(kcs):
        for i, pc in enumerate(pcs):
            if os_matrix[i][j] >= lamda_w:
                N_kc += 1
                break
    return N_kc

def cal_Acc(pcs, kcs):
    Sn_up = 0
    for i in kcs:
        i_set = set(i)
        max_T_ij = 0
        for j in pcs:
            j_set = set(j)
            T_ij = i_set & j_set
            max_T_ij = max(max_T_ij, len(T_ij))
        Sn_up += max_T_ij
    Sn_down = 0
    for i in kcs:
        Sn_down += len(i)
    Sn = float(Sn_up) / float(Sn_down)
    
    PPV_up = 0
    for j in pcs:
        j_set = set(j)
        max_T_ji = 0
        for i in kcs:
            i_set = set(i)
            T_ji = j_set & i_set
            max_T_ji = max(max_T_ji, len(T_ji))
        PPV_up += max_T_ji
    PPV_down = 0
    for j in pcs:
        j_set = set(j)
        for i in kcs:
            i_set = set(i)
            T_ji = j_set & i_set
            PPV_down += len(T_ji)
    PPV = float(PPV_up) / float(PPV_down)
    Acc = np.sqrt(Sn * PPV)
    return Acc

def evaluate_results(pc_file, kc_file):
    print(kc_file)
    pcs, kcs = [], []
    with open(pc_file, 'r') as f:
        content = f.readlines()
        for line in content:
            line = line.strip('\n').strip().split()
#             print(line)
            pcs.append([])
            for i, protein in enumerate(line):
                if i == 0:
                    continue
                else:
                    pcs[-1].append(protein)
    with open(kc_file, 'r') as f:
        content = f.readlines()
        for line in content:
            line = line.strip('\n').strip().split()
            kcs.append([])
            for i, protein in enumerate(line):
                kcs[-1].append(protein)
    
    print('pc number: ', len(pcs))
    print('kc number: ', len(kcs))
    
    # cal OS(pc, kc)
    os_matrix = cal_os(pcs, kcs)
    
    # cal N_pc
    N_pc = cal_Npc(pcs, kcs, os_matrix)
    
    # cal N_kc
    N_kc = cal_Nkc(pcs, kcs, os_matrix)
    
    # cal Precision
    Precision = float(N_pc) / len(pcs)
    
    #cal Recall
    Recall = float(N_kc) / len(kcs)
    
    #cal F_measure
    F_measure = 2.0*Precision*Recall / (Precision+Recall)
    
    #cal ACC
    Acc = cal_Acc(pcs, kcs)
    
    
    print("N_pc: ", N_pc)
    print("N_kc: ", N_kc)
    print("Recall: ", Recall)
    print("Precision: ", Precision)
    print("F-measure: ", F_measure)
    print("Acc: ", Acc)
    print("F + ACC: ", F_measure+Acc)
    
    return len(pcs),len(kcs),N_pc,N_kc,Recall,Precision,F_measure,Acc


# if __name__=="__main__":
def DPCMNE(PPI_file, emd_file, extension_thres, result_file, ref):
#     PPI_file = './datasets/DIP20170205.txt'
#     emd_file = './emd/DIP_128.txt'

    relations, protein_id, id_protein = load_data(PPI_file)
    protein_num = len(protein_id)
    w = np.zeros((protein_num, protein_num))
    w,relations = construct_net_embedding(id_protein, protein_id, relations, w, emd_file)

    #protein_out_file
    protein_out_file = './temp_result/protein_list.txt'
    with open(protein_out_file, 'w') as f:
        for protein_name in protein_id.keys():
            temp_str = str(protein_name)+'\n'
            f.writelines(temp_str)

    #call ConvertPPI.exe
    ppi_num_file = './temp_result/ppi_num_file.txt'
    ppi_matrix_file = './temp_result/ppi_matrix.txt'
    cliques_file = './temp_result/cliques.txt'
    os.system("ConvertPPI.exe "+PPI_file+" "+protein_out_file+" "+ppi_num_file+" "+ppi_matrix_file)
    os.system("Mining_Cliques.exe "+ppi_matrix_file+" 1 3 "+str(protein_num)+" "+cliques_file)
    
    Cores = []
    with open(cliques_file, 'r') as f:
        content = f.readlines()
        for line in content:
            line = line.strip('\n').strip().split()
            protein_len = len(line)
            temp_core = set()
            for i, pid in enumerate(line):
                if i==0:
                    continue
                else:
                    temp_core.add(int(pid))
            temp_core = list(temp_core)
            Cores.append(temp_core)

    #cal density
    Cores_score = []
    for core in Cores:
        density_score = cal_density(core, w)
        temp = (core, density_score)
        Cores_score.append(temp)
    Cores_score.sort(key=lambda tup: tup[1], reverse=True)
    
    Cores = select_cores(Cores_score, w)
    
#     extension_thres = 0.6
    complexes = extension(Cores, id_protein, w, extension_thres)
    save_result(complexes, id_protein, result_file)
    
    evaluate_results(result_file, ref)
from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter
from DPCMNE import DPCMNE

def parse_args():
    parser = ArgumentParser(formatter_class=ArgumentDefaultsHelpFormatter,
                            conflict_handler='resolve')
    parser.add_argument('--input',
                        default='./datasets/DIP20170205.txt',
                        help='input PPI file')
    parser.add_argument('--output',
                        default='result/DPCMNE_DIP_128_0.6.txt',
                        help='output representation file')
    parser.add_argument('--emd',
                        default='./emd/DIP_128.txt',
                        help='embedding file')
    parser.add_argument('--ref',
                        default='./datasets/CYC2008_3_236.txt',
                        help='reference file')
    parser.add_argument('--thres',
                        default=0.6,
                        type=float,
                        help='extension thres')
    
    args = parser.parse_args()

    return args

def main(args):
    ppi_file = args.input
    emd_file = args.emd
    extension_thres = args.thres
    result_file = args.output
    ref = args.ref
    DPCMNE(ppi_file, emd_file, extension_thres, result_file, ref)

if __name__ == '__main__':
    main(parse_args())
# DPCMNE

### How to Start

python3 DPCMNE_start.py

- --input PPI_network.txt
- --output result_file.txt
- --emd emd_file.txt
- --ref reference_file.txt
- --thres extension_thres

```python
python DPCMNE_start.py --input ./datasets/BIOGRID.txt --output ./result/BIOGRID_512_0.4.txt --emd ./emd/BIOGRID_512.txt --ref ./datasets/CYC2008_3_236.txt --thres 0.4
```

